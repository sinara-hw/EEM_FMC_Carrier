designFile = "C:/Users/Admin/Documents/Altium_testy/EEM_FMC_Carrier/PCB/PDNAnalyzer_Output/EEM_FMC_Carrier/odb.tgz"

powerNets = ["P1V0_NF", "P1V0"]

groundNets = ["GND"]

excitation = [
{
"id": "0",
"type": "source",
"power_pins": [ ("C239", "2") ],
"ground_pins": [ ("C239", "1") ],
"voltage": 1,
"Rpin": 0,
}
,
{
"id": "1",
"type": "load",
"power_pins": [ ("IC4", "H8"), ("IC4", "H10"), ("IC4", "J7"), ("IC4", "J9"), ("IC4", "K8"), ("IC4", "L7"), ("IC4", "M8"), ("IC4", "N7"), ("IC4", "P8"), ("IC4", "P10"), ("IC4", "R7"), ("IC4", "R9"), ("IC4", "T8"), ("IC4", "T10") ],
"ground_pins": [ ("IC4", "A2"), ("IC4", "A3"), ("IC4", "A5"), ("IC4", "A7"), ("IC4", "A9"), ("IC4", "A11"), ("IC4", "A12"), ("IC4", "A22"), ("IC4", "B3"), ("IC4", "B12"), ("IC4", "B19"), ("IC4", "C3"), ("IC4", "C6"), ("IC4", "C10"), ("IC4", "C12"), ("IC4", "C16"), ("IC4", "D3"), ("IC4", "D4"), ("IC4", "D8"), ("IC4", "D12"), ("IC4", "D13"), ("IC4", "E4"), ("IC4", "E5"), ("IC4", "E7"), ("IC4", "E9"), ("IC4", "E11"), ("IC4", "E12"), ("IC4", "E20"), ("IC4", "F5"), ("IC4", "F11"), ("IC4", "F17"), ("IC4", "G5"), ("IC4", "G6"), ("IC4", "G7"), ("IC4", "G8"), ("IC4", "G9"), ("IC4", "G10"), ("IC4", "G12"), ("IC4", "G14"), ("IC4", "H1"), ("IC4", "H7"), ("IC4", "H9"), ("IC4", "H11"), ("IC4", "H21"), ("IC4", "J8"), ("IC4", "J10"), ("IC4", "J12"), ("IC4", "J18"), ("IC4", "K5"), ("IC4", "K7"), ("IC4", "K11"), ("IC4", "K15"), ("IC4", "L2"), ("IC4", "L8"), ("IC4", "L22"), ("IC4", "M7"), ("IC4", "M11"), ("IC4", "M19"), ("IC4", "N6"), ("IC4", "N8"), ("IC4", "N16"), ("IC4", "P3"), ("IC4", "P7"), ("IC4", "P9"), ("IC4", "P11"), ("IC4", "P13"), ("IC4", "R8"), ("IC4", "R10"), ("IC4", "R12"), ("IC4", "R20"), ("IC4", "T7"), ("IC4", "T9"), ("IC4", "T11"), ("IC4", "T17"), ("IC4", "U4"), ("IC4", "U9"), ("IC4", "U10"), ("IC4", "U14"), ("IC4", "V1"), ("IC4", "V11"), ("IC4", "V21"), ("IC4", "W8"), ("IC4", "W18"), ("IC4", "Y5"), ("IC4", "Y15"), ("IC4", "AA2"), ("IC4", "AA12"), ("IC4", "AA22"), ("IC4", "AB9"), ("IC4", "AB19") ],
"current": 0.4,
"Rpin": 6.05769230769231,
}
]


voltage_regulators = [
{
"id": "2",
"type": "linear",

"in": [ ("L12", "1") ],
"out": [ ("L12", "2") ],
"ref": [],

"v2": 0,
"i1": 0,
"Ro": 1E-06,
"Rpin": 5E-07,
}
]


# Resistors / Inductors

passives = []


# Material Properties:

tech = [

        {'name': 'TOPSOLDER', 'DielectricConstant': 3.5, 'Thickness': 2.2E-05},
        {'name': 'TOPLAYER', 'Conductivity': 47000000, 'Thickness': 5.3E-05},
        {'name': 'SUBSTRATE-1', 'DielectricConstant': 4.2, 'Thickness': 0.00011},
        {'name': 'MIDLAYER1', 'Conductivity': 47000000, 'Thickness': 1.8E-05},
        {'name': 'SUBSTRATE-2', 'DielectricConstant': 4.2, 'Thickness': 0.0002},
        {'name': 'MIDLAYER2', 'Conductivity': 47000000, 'Thickness': 1.8E-05},
        {'name': 'SUBSTRATE-3', 'DielectricConstant': 4.2, 'Thickness': 0.00073},
        {'name': 'SIGNALLAYER1', 'Conductivity': 47000000, 'Thickness': 1.8E-05},
        {'name': 'SUBSTRATE-4', 'DielectricConstant': 4.2, 'Thickness': 0.0002},
        {'name': 'INTERNAL_PLANE_1', 'Conductivity': 47000000, 'Thickness': 1.8E-05},
        {'name': 'SUBSTRATE-5', 'DielectricConstant': 4.2, 'Thickness': 0.00011},
        {'name': 'BOTTOMLAYER', 'Conductivity': 47000000, 'Thickness': 5.3E-05},
        {'name': 'BOTTOMSOLDER', 'DielectricConstant': 3.5, 'Thickness': 2.2E-05}

       ]

special_settings = {'removecutoutsize' : 7.8 }


plating_thickness = 0.7
finished_hole_diameters = False
